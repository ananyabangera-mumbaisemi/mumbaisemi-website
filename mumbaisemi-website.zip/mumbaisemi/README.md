# MumbaiSemi Website

A single-page, professional website for MumbaiSemi — fab-less semiconductor design company.

## What's inside
- `index.html` — the full website (HTML + CSS + JS, no build step required)
- `assets/logo.png` — original logo (color, white background)
- `assets/logo-transparent.png` — logo with transparent background
- `assets/logo-white.png` — white version of the logo, used in the dark navbar/footer

## Sections included
1. Sticky dark navbar
2. Hero (dark, circuit-trace accents, key stats)
3. About Us
4. Capabilities (RF / Analog / Mixed-signal / Digital)
5. Industries served (Navigation, Wireless, High-speed comms, Automotive)
6. DhruvaPro product spotlight (flagship IP)
7. Technology & design process (4-step flow)
8. Team & leadership (placeholder cards — replace with real photos/bios)
9. Careers + open roles
10. Ecosystem / partners (SINE IIT Bombay etc.)
11. Insights / news cards
12. Contact (info + form)
13. Footer

## Before going live — things to update
- **Team section**: replace "FN", "CN", "TL" placeholder initials/bios with real team photos and bios.
- **Open roles**: edit or remove if not currently hiring.
- **Contact form**: the form currently shows a placeholder alert on submit. To actually receive
  messages, connect it to a form backend such as:
  - Formspree (formspree.io) — add `action="https://formspree.io/f/YOUR_ID"` and `method="POST"` to the `<form>` tag, remove the JS alert.
  - Netlify Forms — if hosting on Netlify, add `data-netlify="true"` and `name="contact"` to the form.
  - Or any custom backend endpoint.
- **Insights section**: replace placeholder news cards with real updates as they happen.
- **Favicon**: add a `<link rel="icon" href="assets/favicon.png">` in the `<head>` using a small square version of your logo.

## How to host this (no coding needed)

### Option 1 — Netlify (easiest, free)
1. Go to https://app.netlify.com/drop
2. Drag and drop the whole `mumbaisemi` folder (containing `index.html` and `assets/`) onto the page.
3. Netlify gives you a live URL instantly. You can later add a custom domain (mumbaisemi.com) in Netlify's domain settings.

### Option 2 — GitHub Pages (free)
1. Create a GitHub repository (e.g. `mumbaisemi-website`).
2. Upload `index.html` and the `assets/` folder to the repo.
3. Go to Settings → Pages → set source to the `main` branch, root folder.
4. Your site will be live at `https://yourusername.github.io/mumbaisemi-website/`.
5. Add a custom domain in the same Pages settings.

### Option 3 — Vercel (free)
1. Go to https://vercel.com, sign up, click "Add New Project".
2. Choose "Deploy without Git" / drag-and-drop the folder, or connect a GitHub repo.
3. Vercel deploys it and gives you a live URL + custom domain support.

### Connecting your existing domain (mumbaisemi.com)
Whichever host you choose, the domain dashboard will give you DNS records (usually A and/or CNAME records) to add at your domain registrar (GoDaddy, Namecheap, etc.). Once added, the host's free SSL automatically secures the site with HTTPS.

## Editing content later
Everything is in `index.html` — text, links, and section order can be edited directly. Colors and
spacing are controlled via CSS variables at the top of the `<style>` block (`--navy`, `--blue`,
`--cyan`, etc.) if you want to tweak the palette.
